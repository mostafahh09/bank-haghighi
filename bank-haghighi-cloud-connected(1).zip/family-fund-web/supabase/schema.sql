
-- صندوق خانوادگی: طرح پایگاه داده Supabase/PostgreSQL
-- قبل از استفاده، این فایل را در SQL Editor پروژه Supabase اجرا کنید.

create extension if not exists pgcrypto;

create table if not exists public.funds (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'صندوق خانوادگی',
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  fund_id uuid references public.funds(id) on delete cascade,
  role text not null default 'member' check (role in ('admin','member')),
  member_id uuid,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  fund_id uuid not null references public.funds(id) on delete cascade,
  name text not null,
  phone text,
  shares numeric(14,2) not null default 1 check (shares > 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles
  drop constraint if exists profiles_member_id_fkey;
alter table public.profiles
  add constraint profiles_member_id_fkey
  foreign key (member_id) references public.members(id) on delete set null;

create table if not exists public.deposits (
  id uuid primary key default gen_random_uuid(),
  fund_id uuid not null references public.funds(id) on delete cascade,
  member_id uuid not null references public.members(id),
  amount numeric(18,2) not null check (amount > 0),
  paid_at timestamptz not null default now(),
  note text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.loans (
  id uuid primary key default gen_random_uuid(),
  fund_id uuid not null references public.funds(id) on delete cascade,
  member_id uuid not null references public.members(id),
  principal numeric(18,2) not null check (principal > 0),
  interest_rate numeric(8,3) not null default 0,
  interest_amount numeric(18,2) not null default 0,
  total_amount numeric(18,2) not null,
  installment_count integer not null check (installment_count > 0),
  schedule jsonb not null default '[]'::jsonb,
  start_date date,
  note text,
  status text not null default 'active' check (status in ('active','paid','cancelled')),
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.loan_payments (
  id uuid primary key default gen_random_uuid(),
  fund_id uuid not null references public.funds(id) on delete cascade,
  loan_id uuid not null references public.loans(id) on delete cascade,
  member_id uuid not null references public.members(id),
  amount numeric(18,2) not null check (amount > 0),
  paid_at timestamptz not null default now(),
  note text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create table if not exists public.fund_settings (
  fund_id uuid primary key references public.funds(id) on delete cascade,
  amount_per_share numeric(18,2) not null default 500000,
  settings jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  fund_id uuid not null references public.funds(id) on delete cascade,
  actor_id uuid references auth.users(id),
  action text not null,
  table_name text not null,
  record_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists idx_profiles_fund on public.profiles(fund_id);
create index if not exists idx_members_fund on public.members(fund_id);
create index if not exists idx_deposits_fund_member_date on public.deposits(fund_id, member_id, paid_at desc);
create index if not exists idx_loans_fund_member on public.loans(fund_id, member_id);
create index if not exists idx_loan_payments_loan on public.loan_payments(loan_id, paid_at desc);

create or replace function public.current_fund_id()
returns uuid language sql stable security definer set search_path = public
as $$ select fund_id from public.profiles where id = auth.uid() $$;

create or replace function public.current_member_id()
returns uuid language sql stable security definer set search_path = public
as $$ select member_id from public.profiles where id = auth.uid() $$;

create or replace function public.is_fund_admin(target_fund uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (
  select 1 from public.profiles
  where id = auth.uid() and fund_id = target_fund and role = 'admin'
) $$;

alter table public.funds enable row level security;
alter table public.profiles enable row level security;
alter table public.members enable row level security;
alter table public.deposits enable row level security;
alter table public.loans enable row level security;
alter table public.loan_payments enable row level security;
alter table public.fund_settings enable row level security;
alter table public.audit_logs enable row level security;

drop policy if exists "fund read own" on public.funds;
create policy "fund read own" on public.funds for select to authenticated
using (id = public.current_fund_id());

drop policy if exists "profile self or admin read" on public.profiles;
create policy "profile self or admin read" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_fund_admin(fund_id));

drop policy if exists "admin manage profiles" on public.profiles;
create policy "admin manage profiles" on public.profiles for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));

drop policy if exists "members read own or admin" on public.members;
create policy "members read own or admin" on public.members for select to authenticated
using (fund_id = public.current_fund_id() and
       (public.is_fund_admin(fund_id) or id = public.current_member_id()));

drop policy if exists "admin manage members" on public.members;
create policy "admin manage members" on public.members for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));

drop policy if exists "deposits read own or admin" on public.deposits;
create policy "deposits read own or admin" on public.deposits for select to authenticated
using (fund_id = public.current_fund_id() and
       (public.is_fund_admin(fund_id) or member_id = public.current_member_id()));

drop policy if exists "admin manage deposits" on public.deposits;
create policy "admin manage deposits" on public.deposits for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));

drop policy if exists "loans read own or admin" on public.loans;
create policy "loans read own or admin" on public.loans for select to authenticated
using (fund_id = public.current_fund_id() and
       (public.is_fund_admin(fund_id) or member_id = public.current_member_id()));

drop policy if exists "admin manage loans" on public.loans;
create policy "admin manage loans" on public.loans for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));

drop policy if exists "payments read own or admin" on public.loan_payments;
create policy "payments read own or admin" on public.loan_payments for select to authenticated
using (fund_id = public.current_fund_id() and
       (public.is_fund_admin(fund_id) or member_id = public.current_member_id()));

drop policy if exists "admin manage payments" on public.loan_payments;
create policy "admin manage payments" on public.loan_payments for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));

drop policy if exists "settings read fund" on public.fund_settings;
create policy "settings read fund" on public.fund_settings for select to authenticated
using (fund_id = public.current_fund_id());

drop policy if exists "admin manage settings" on public.fund_settings;
create policy "admin manage settings" on public.fund_settings for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));

drop policy if exists "audit admin read" on public.audit_logs;
create policy "audit admin read" on public.audit_logs for select to authenticated
using (public.is_fund_admin(fund_id));

drop policy if exists "audit authenticated insert" on public.audit_logs;
create policy "audit authenticated insert" on public.audit_logs for insert to authenticated
with check (fund_id = public.current_fund_id() and actor_id = auth.uid());

-- برای ایجاد مدیر اولیه:
-- 1) ابتدا در Authentication > Users یک کاربر بسازید.
-- 2) UUID کاربر را جایگزین مقدار زیر کنید.
-- 3) این دستورات را یک‌بار در SQL Editor اجرا کنید.
-- insert into public.funds(name) values ('صندوق خانوادگی') returning id;
-- insert into public.profiles(id, fund_id, role, display_name)
-- values ('AUTH-USER-UUID', 'FUND-UUID', 'admin', 'مدیر صندوق');
-- insert into public.fund_settings(fund_id) values ('FUND-UUID');


-- مخزن وضعیت برنامه بانک حقیقی؛ فقط مدیر همان صندوق اجازه خواندن/نوشتن دارد.
create table if not exists public.app_state (
  fund_id uuid primary key references public.funds(id) on delete cascade,
  state jsonb not null default '{}'::jsonb,
  updated_by uuid references auth.users(id),
  updated_at timestamptz not null default now()
);
alter table public.app_state enable row level security;
drop policy if exists "admin manage app state" on public.app_state;
create policy "admin manage app state" on public.app_state for all to authenticated
using (public.is_fund_admin(fund_id)) with check (public.is_fund_admin(fund_id));
grant select, insert, update on public.app_state to authenticated;
